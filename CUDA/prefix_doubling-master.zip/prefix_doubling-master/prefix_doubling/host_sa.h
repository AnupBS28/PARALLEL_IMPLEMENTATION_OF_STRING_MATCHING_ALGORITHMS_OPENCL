#pragma once

//CPU sa construction 
//Borrowed from: http://codeforces.com/blog/entry/4025
void host_sa(const unsigned char * S, int * sa, int n);